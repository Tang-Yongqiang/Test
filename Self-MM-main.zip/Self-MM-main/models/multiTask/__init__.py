from models.multiTask.SELF_MM import SELF_MM

__all__ = ['SELF_MM']